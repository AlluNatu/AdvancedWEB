const logout = () => {
    localStorage.removeItem('token')
    window.location.href = '/register.html'
}

document.getElementById("logout").addEventListener("click", logout)

const initializeLogin = () => {
    document.getElementById("loginForm").addEventListener("submit", (event) => {
        fetchData(event)
    })
}

const fetchData = async (event) => {
    event.preventDefault()

    const formData = {
        email: event.target.email.value,
        password: event.target.password.value,
    }

    try {
        const response = await fetch("/api/user/login",  {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(formData)
        })
        if (!response.ok) {
            console.log(response);
            
        } else {
            const data = await response.json()
            console.log(data);
            
            
            if(data.token) {
                localStorage.setItem('token', data.token)
                window.location.href = "/"
            }
            
        }

    } catch (error) {
        console.log(`Error while trying to login: ${error.message}`)
    }


}

async function coolFunction() {
    const token = localStorage.getItem('token')
    if (token) {
        let formDiv = document.getElementById("topicForm");
    }
} 

function createTopic(){
    let topicForm = document.getElementById("topicForm")

    let inputField = document.createElement("input");
    let inputText = document.createElement("input");
    let button = document.createElement("input");
  
    inputField.type = "text"
    inputText.type = "text"
    button.type = "submit"
    inputField.id = "topicTitle"
    inputText.id = "topicText"
    button.id = "postTopic"
    button.innerText = "button"
  
    topicForm.appendChild(inputField)
    topicForm.appendChild(inputText)
    topicForm.appendChild(button)

    button.addEventListener("click", async (param) => {
        param.preventDefault()
    
        
    
        let data = {name:name, todos:todos}
        const res = await fetch('/add', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data),
        })
    
        const result = await res.json()
        jsonSuccess.textContent = result.message
    })

}
const loadCoolTopics = async(offers) => {
    offersContainer.innerHTML = ''
    offersContainer.classList.add("row")

    offers.forEach(offer => {
        const Div = document.createElement('div');
        Div.classList.add('col', 's12', 'm6', 'l4', 'offerDiv');
    
        let imageHTML = '';
        if (offer.imagePath) {
            imageHTML = `<img class="responsive-img" src="./${offer.imagePath}">`;

        }
    
        Div.innerHTML = `
            <div class="card hoverable">
                <div class="card-image">
                    ${imageHTML}
                    <span class="card-title">${offer.title}</span>
                </div> 
                <div class="card-content">
                    <p>${offer.description}</p>
                    <p>Price: ${offer.price}€</p>
                </div>
            </div>`
        offersContainer.appendChild(Div);
        console.log(Div)
    })
    
}

coolFunction()

initializeLogin()